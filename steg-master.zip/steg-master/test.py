# Import library
from steg import steg_img

# Hiding
# Select your payload and carrier files
s = steg_img.IMG(payload_path="pay.txt", image_path="img.png")
# Create a new image containing your payload
s.hide()

# Extracting
# Select the carrier image
s_prime = steg_img.IMG(image_path="new.png")
# Extract the payload
s_prime.extract()