# Digital-Image-Watermarking-Using-Optimised-DWT-DCT

This repository is for the free code of digital image watermarking . You need to run the file 'manit.m' in MATLAB and follow the setps shown in video https://youtu.be/jgkaG8hA5vo. More information can be found on our blog http://free-thesis.com/product/digital-image-watermarking-using-optimized-dwt-dct/. 

![Digital Image Watermarking using DWT DCT](http://free-thesis.com/wp-content/uploads/2018/04/8-2016_09_06-04_26_33-UTC.png)


